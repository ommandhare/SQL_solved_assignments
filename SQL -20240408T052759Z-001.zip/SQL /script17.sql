use school;

alter table marks add column geography_per float; 