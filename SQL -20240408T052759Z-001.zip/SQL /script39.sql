use retail;
select  member_id,reg_date,store_id from member;