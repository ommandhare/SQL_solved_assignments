use retail;

insert into product values
('101','',5,'indian','4'),
('102','',4,'indian','5'),
('103','',2,'indian','3');
