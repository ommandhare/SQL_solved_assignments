
use retail;
select * from tran_hdr where store_id='2';
