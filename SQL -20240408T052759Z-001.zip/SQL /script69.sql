select * from product;

select count(product_id),category from product group by category;
