use blood_bank;

alter table donor add column donor_address varchar(255);