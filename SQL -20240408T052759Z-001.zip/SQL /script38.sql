use retail;
select  member_id,first_name,last_name from member;