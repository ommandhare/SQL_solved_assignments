use shrileela;

alter table wing_a add column number_of_guests int;

alter table wing_b add column number_of_guests int;