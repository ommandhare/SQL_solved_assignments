use employees;

select emp_no,first_name from employees;