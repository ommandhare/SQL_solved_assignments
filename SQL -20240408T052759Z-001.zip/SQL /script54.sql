use employees;

select avg(salary) as average_salary from salaries;