use retail;
insert into store_dtl values
(1, 'Satara', 'Maharashtra',02162-234567),
(2, 'Pune', 'Maharashtra',020-23456789),
(3, 'Aurangabad', 'Maharashtra',0240-2345678);
