use family;
create database family;

create table family_dtl(
first_name varchar(40),
middle_name varchar(40),
last_name varchar(40),
age int,
relation_with_yourself varchar(40)
);


