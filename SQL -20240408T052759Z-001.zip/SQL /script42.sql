use retail;

select tran_id,member_id,store_id,tran_dt from tran_hdr;