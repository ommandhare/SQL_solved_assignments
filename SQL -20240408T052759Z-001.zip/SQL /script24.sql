use shrileela;

alter table wing_a drop column number_of_guests;

