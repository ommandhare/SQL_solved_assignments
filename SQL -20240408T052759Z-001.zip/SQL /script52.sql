use employees;
select count(emp_no) from employees;