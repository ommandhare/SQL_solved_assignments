use retail;

SELECT product_id,description,category FROM product

WHERE category IN ("Baked Goods", "Dairy");



