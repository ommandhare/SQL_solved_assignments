use retail;
select member_id,tran_dt from tran_hdr where month(tran_dt)=1;