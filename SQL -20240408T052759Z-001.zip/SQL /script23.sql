use blood_bank;

alter table donor rename column donor_address to permenant_address;