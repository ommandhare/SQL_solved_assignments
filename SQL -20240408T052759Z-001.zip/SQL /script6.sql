create database school;
use school;
create table student(
Roll_no int,
first_name varchar(40),
last_name varchar(40),
DOB date
);


