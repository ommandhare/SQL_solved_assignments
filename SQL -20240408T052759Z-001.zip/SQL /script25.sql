use blood_bank;

alter table donor drop column permanent_address;