use employees;

select * from titles;