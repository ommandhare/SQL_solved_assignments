use school;

alter table student rename column standard to student_std; 