use retail;

select product_id,description,price from product;