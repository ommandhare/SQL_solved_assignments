use school;

alter table student add column standard int; 