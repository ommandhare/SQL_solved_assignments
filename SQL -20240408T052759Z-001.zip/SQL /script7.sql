use school;

create table marks(
Roll_no int,
maths_marks float,
English_marks float,
science_marks float
);


