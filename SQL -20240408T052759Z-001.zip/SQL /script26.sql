use blood_bank;

drop table donor; 