use retail;

select * from product;