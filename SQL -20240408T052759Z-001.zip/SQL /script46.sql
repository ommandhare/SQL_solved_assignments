use employees;
select first_name,birth_date from employees where year(birth_date)='1960';  