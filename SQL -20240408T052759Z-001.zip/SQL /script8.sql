create database shrileela;
use shrileela;

create table Wing_a(
flat_No int ,
owner_name varchar(40),
mobile_number int
);


