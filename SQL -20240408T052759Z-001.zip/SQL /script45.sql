use retail;
select AVG(price) from product where category='Baked goods';