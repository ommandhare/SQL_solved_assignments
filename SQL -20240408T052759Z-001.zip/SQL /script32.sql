use retail;

SELECT product_id,description,category FROM product;
