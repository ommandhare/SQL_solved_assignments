use family;

alter table family_dtl drop column age;