use school;


alter table marks rename column per_marks to percent_marks; 