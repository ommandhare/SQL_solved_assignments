use family;

drop table family_dtl;