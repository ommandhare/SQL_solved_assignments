use employees;

select * from departments;