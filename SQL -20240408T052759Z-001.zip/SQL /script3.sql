use retail;

create table store_dtl(
store_id int,
store_city varchar(40),
store_state varchar(40),
contact_no int
);
