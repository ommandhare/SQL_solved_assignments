use employees;

select * from employees;