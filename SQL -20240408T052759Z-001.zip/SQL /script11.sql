use family;

alter table family_dtl ADD column city varchar(255);