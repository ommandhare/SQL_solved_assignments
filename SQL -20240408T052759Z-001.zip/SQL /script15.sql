use library;

ALTER TABLE book_dtl RENAME COLUMN price TO book_price;