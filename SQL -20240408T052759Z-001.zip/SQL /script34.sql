use employees;

select * from salaries;