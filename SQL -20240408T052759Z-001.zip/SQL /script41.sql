use retail;

select tran_id,qty,amt from tran_dtl;